# 20-20-20 (EyeRest)

Minimalist iOS timer: 20 min focus → 20 sec look 20 ft away → repeat.
Alerts are scheduled as local notifications, so they fire with the app closed or the phone locked.

## Get the IPA (no Mac needed)
1. Create a new GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the repo → **Actions** → "Build IPA" (it runs on push; or click "Run workflow").
3. When it finishes, download the **EyeRest-ipa** artifact and unzip it to get `EyeRest.ipa`.

## Install
The IPA is unsigned. Sign and install it with one of:
- **Sideloadly** (Windows/Mac) – drag in the IPA, enter your Apple ID (free accounts: re-sign every 7 days)
- **AltStore / SideStore**
- **TrollStore** (if your iOS version supports it – permanent install)

On first launch, tap Start and allow notifications.

## Build on a Mac instead
`brew install xcodegen && xcodegen generate && open EyeRest.xcodeproj`
